🌐 Render Setup Instructions:

1. Environment: Python
2. Build Command:
   pip install -r requirements.txt
3. Start Command:
   python main.py
4. Name: SpinAndWinBot (or any name you prefer)

✅ After deploy, open Telegram and send /start to your bot to test.
